import junit.framework.TestCase;
public class FindFakeBallTest extends TestCase {
    int ball_weitht1[] = {1, 2, 2, 2, 2, 2, 2, 2, 2, 2};
    int ball_weitht2[] = {2, 1, 2, 2, 2, 2, 2, 2, 2, 2};
    int ball_weitht3[] = {2, 2, 1, 2, 2, 2, 2, 2, 2, 2};
    int ball_weitht4[] = {2, 2, 2, 1, 2, 2, 2, 2, 2, 2};
    int ball_weitht5[] = {2, 2, 2, 2, 1, 2, 2, 2, 2, 2};
    int ball_weitht6[] = {2, 2, 2, 2, 2, 1, 2, 2, 2, 2};
    int ball_weitht7[] = {2, 2, 2, 2, 2, 2, 1, 2, 2, 2};
    int ball_weitht8[] = {2, 2, 2, 2, 2, 2, 2, 1, 2, 2};
    int ball_weitht9[] = {2, 2, 2, 2, 2, 2, 2, 2, 1, 2};
    int ball_weitht10[] = {2, 2, 2, 2, 2, 2, 2, 2, 2, 1};
    public void test() {
        FindFakeBall balls1 = new FindFakeBall();
        balls1.set_ball_weight(ball_weitht1);  
        assertEquals("1号球是假球", balls1.Find());

        FindFakeBall balls2 = new FindFakeBall();
        balls2.set_ball_weight(ball_weitht2);  
        assertEquals("2号球是假球", balls2.Find());

        FindFakeBall balls3 = new FindFakeBall();
        balls3.set_ball_weight(ball_weitht3);  
        assertEquals("3号球是假球", balls3.Find());

        FindFakeBall balls4 = new FindFakeBall();
        balls4.set_ball_weight(ball_weitht4);  
        assertEquals("4号球是假球", balls4.Find());

        FindFakeBall balls5 = new FindFakeBall();
        balls5.set_ball_weight(ball_weitht5);  
        assertEquals("5号球是假球", balls5.Find());

        FindFakeBall balls6 = new FindFakeBall();
        balls6.set_ball_weight(ball_weitht6);  
        assertEquals("6号球是假球", balls6.Find());

        FindFakeBall balls7 = new FindFakeBall();
        balls7.set_ball_weight(ball_weitht7);  
        assertEquals("7号球是假球", balls7.Find());

        FindFakeBall balls8 = new FindFakeBall();
        balls8.set_ball_weight(ball_weitht8);  
        assertEquals("8号球是假球", balls8.Find());

        FindFakeBall balls9 = new FindFakeBall();
        balls9.set_ball_weight(ball_weitht9);  
        assertEquals("9号球是假球", balls9.Find());

        FindFakeBall balls10 = new FindFakeBall();
        balls10.set_ball_weight(ball_weitht10);  
        assertEquals("10号球是假球", balls10.Find());
    }
    public static void main(String args[]) 
    {
        junit.textui.TestRunner.run(FindFakeBallTest.class);
    }
}
