import junit.framework.TestCase;
import static org.junit.Assert.assertNotEquals;
public class TriangleTest extends TestCase{
    public void test() {
        Triangle triangle = new Triangle();
        assertEquals("一般三角形", triangle.TriangleJudge(3, 4, 5));
        assertEquals("等边三角形", triangle.TriangleJudge(3, 3, 3));
        assertEquals("等腰三角形", triangle.TriangleJudge(3, 3, 4));
        assertEquals("等腰三角形", triangle.TriangleJudge(3, 4, 3));
        assertEquals("等腰三角形", triangle.TriangleJudge(4, 3, 3));
        assertEquals("边长不合法", triangle.TriangleJudge(0, 1, 1));
        assertEquals("边长不合法", triangle.TriangleJudge(1, 0, 1));
        assertEquals("边长不合法", triangle.TriangleJudge(1, 1, 0));
        assertEquals("不构成三角形", triangle.TriangleJudge(1, 1, 3));
        assertEquals("不构成三角形", triangle.TriangleJudge(1, 3, 1));
        assertEquals("不构成三角形", triangle.TriangleJudge(3, 1, 4));
        assertNotEquals("等边三角形", triangle.TriangleJudge(2, 3, 3));
        assertNotEquals("等边三角形", triangle.TriangleJudge(3, 3, 2));
        assertNotEquals("等边三角形", triangle.TriangleJudge(3, 2, 3));
        assertNotEquals("等腰三角形", triangle.TriangleJudge(3, 4, 5));
    }
    public static void main(String args[]) {
        junit.textui.TestRunner.run(TriangleTest.class);
    }
}