public class FindFakeBall {
    private static int weight[] = new int[10];
    public FindFakeBall() {}
    public void set_ball_weight(int input_ball_weight[]) {  // 初始化10个球的重量
        for (int i = 0; i < input_ball_weight.length; i++) {
            weight[i] = input_ball_weight[i];
        }
    }

    public String Find() {
        if (weight[0] + weight[1] + weight[2] + weight[3] + weight[4] < weight[5] + weight[6] + weight[7] + weight[8] + weight[9]) {  // 1-5号球中有假球
            if (weight[1] + weight[2] == weight[3] + weight[4]) {  // 2-5号球不是假球
                System.out.println("1号球是假球");
                return "1号球是假球";
            }
            else if (weight[1] + weight[2] < weight[3] + weight[4]) {  // 2-3号球中有假球
                if (weight[1] < weight[2]) {
                    System.out.println("2号球是假球");
                    return "2号球是假球";
                }
                else {
                    System.out.println("3号球是假球");
                    return "3号球是假球";
                }
            }
            else {    // 4-5号球中有假球
                if (weight[3] < weight[4]) {
                    System.out.println("4号球是假球");
                    return "4号球是假球";
                }
                else {
                    System.out.println("5号球是假球");
                    return "5号球是假球";
                }
            }
        }
        else {  // 6-10号球中有假球
            if (weight[6] + weight[7] == weight[8] + weight[9]) {  // 7-10号球不是假球
                System.out.println("6号球是假球");
                return "6号球是假球";
            }
            else if (weight[6] + weight[7] < weight[8] + weight[9]) {  // 7-8号球中有假球
                if (weight[6] < weight[7]) {
                    System.out.println("7号球是假球");
                    return "7号球是假球";
                }
                else {
                    System.out.println("8号球是假球");
                    return "8号球是假球";
                }
            }
            else {  // 9-10号球中有假球
                if (weight[8] < weight[9]) {
                    System.out.println("9号球是假球");
                    return "9号球是假球";
                }
                else {
                    System.out.println("10号球是假球");
                    return "10号球是假球";
                }
            }
        }
    }
}
