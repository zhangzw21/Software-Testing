public class Triangle {
    public String TriangleJudge(int a, int b, int c) {
        if (a <= 0 || b <= 0 || c <= 0) {  // 边长必须为正数
            System.out.println("边长不合法");
            return "边长不合法";
        }
        else if (a + b > c && a + c > b && b + c > a) {  // 任意两边之和大于第三边
            if (a == b && a == c && b == c) {  // 三边相等
                System.out.println("等边三角形");
                return "等边三角形";
            }
            else if (a == b || a == c || b == c) {  // 两边相等
                System.out.println("等腰三角形");
                return "等腰三角形";
            }            
            else {  // 三边不等
                System.out.println("一般三角形");
                return "一般三角形";
            }
        }
        else {  // 存在某两边之和不满足大于第三边
            System.out.println("不构成三角形");
            return "不构成三角形";
        }
    }
}




